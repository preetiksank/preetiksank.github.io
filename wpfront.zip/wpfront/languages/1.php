‰PNG
<?
echo "<h1>test";
?>
